/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

package hitbtc.api.market;


public class Ticker {
    public double last, bid, ask, high, low, volume, open, volume_quote;
    public long timestamp;
}
