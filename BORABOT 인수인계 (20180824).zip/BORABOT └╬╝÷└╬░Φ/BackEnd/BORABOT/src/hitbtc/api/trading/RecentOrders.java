/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

package hitbtc.api.trading;

import hitbtc.api.market.RecentTrade;

import java.util.ArrayList;

public class RecentOrders {
    public ArrayList<RecentTrade> tradeOrders = new ArrayList<>();
}
