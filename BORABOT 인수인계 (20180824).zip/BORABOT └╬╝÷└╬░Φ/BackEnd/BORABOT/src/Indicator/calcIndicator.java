package Indicator;

public interface calcIndicator {

	public int getDeterminConstant() throws Exception;
	
}
