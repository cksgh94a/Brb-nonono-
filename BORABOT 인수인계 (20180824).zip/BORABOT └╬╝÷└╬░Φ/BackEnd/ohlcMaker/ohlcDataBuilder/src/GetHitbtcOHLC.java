
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GetHitbtcOHLC extends Thread {

	// https://api.hitbtc.com/api/2/public/trades/ETHBTC?sort=DESC&limit=500
	final static String baseUrl = "https://api.hitbtc.com/api/2/public/trades/"; //
	private final static int retryAttempts = 10;
	private static int retryAttemptsLeft = 10;
	private final static int retryDelaySeconds = 3;
	// private String[] coinList = { "BTCUSDT", "BCHBTC", "ETHUSDT", "EOSDAI",
	// "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC", "LTCUSDT", "DASHBTC", "ZRXETH",
	// "ZECBTC" };
	// 원래는 USDT인데 API콜 할때 SYMBOL에 넣을떄는 USD로 표시해서 넣어야함
	private String[] coinList = { "BTCUSD", "BCHBTC", "ETHUSD", "XRPBTC", "ETHBTC", "BCHUSD", "XMRBTC", "LTCUSD",
			"DASHBTC", "ZRXETH", "ZECBTC" };
	private String[] coinList4DB = { "BTCUSDT", "BCHBTC", "ETHUSDT", "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC", "LTCUSDT",
			"DASHBTC", "ZRXETH", "ZECBTC" };
	private long[] prevTimeForCoin = new long[coinList.length];
	private static int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };
	private volatile static long[] startUtime = new long[intervalList.length];
	private long startUtimeSingle;
	private static int orderInterval = 60;
	private DBinsert dbInsert = new DBinsert();

	public GetHitbtcOHLC(long ut) {
		this.startUtimeSingle = ut;
		Arrays.fill(startUtime, ut);
		Arrays.fill(prevTimeForCoin, ut - 1);
	}

	public static Date utToDate(long Utime) {

		Date date = new Date();
		date.setTime((long) Utime * 1000);

		return date;
	}

	public static long dateToUt(String dateStr) {

		long currentuTime = 0;
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateStr);
			currentuTime = date.getTime() / 1000;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return currentuTime;
	}

	@Override
	public void run() {
		Timer timer = new Timer();
		
		// 빗썸과 거의 동일
		// 빗썸의 주석을 참고해주시면 감사하겠습니다.
		TimerTask taskForOneMinute = new TimerTask() {
			@Override
			public void run() {

				for (int i = 0; i < coinList.length; i++) {

					String result; // 에러
					try {
						result = getOrder(coinList[i]); // 에러
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("힛비티씨 오류");
						continue;
					}

					JsonArray jsArr = null;
					try {
						jsArr = new JsonParser().parse(result).getAsJsonArray();
					} catch (Exception e) {
						e.printStackTrace();
						continue;
					}

					if (jsArr.size() == 0) {
						// System.out.println("hitbtc" + coinList[i] + " no order");
					} else {
						JsonObject jsObj1 = jsArr.get(0).getAsJsonObject();
						String tempDate1 = jsObj1.get("timestamp").getAsString();
						long tempPrev = dateToUt(tempDate1.replace('T', ' '));

						// 0 번쨰가 가장 최근?! -> 맞어, 빗썸이랑 힛빝이랑
						for (int j = 0; j < jsArr.size(); j++) {

							JsonObject jsObj = jsArr.get(j).getAsJsonObject();

							String tempDate = jsObj.get("timestamp").getAsString();

							long currentuTime = dateToUt(tempDate.replace('T', ' '));

							// System.out.println(j +"th : " + currentuTime);

							if (currentuTime > prevTimeForCoin[i]) {
								// 삽입
								long id = jsObj.get("id").getAsLong();
								double price = jsObj.get("price").getAsDouble();

							
								long uTime = dateToUt(jsObj.get("timestamp").getAsString().replace('T', ' '));
								double v = jsObj.get("quantity").getAsDouble();

								String insertSQL = String.format(
										"INSERT INTO hitbtcOneMinute%s VALUES (%s, %s, %s, %s) ", coinList4DB[i], id,
										uTime + 32400, price, v);

								dbInsert.Query(insertSQL, "insert");

							} else {
								break;
							}
						}

						// 마지막에 prev에다가 넣어줌
						prevTimeForCoin[i] = tempPrev;

					}
				}

				// System.out.println(orderInterval + "sec order hitbtc insertion done");
			}
		};

		TimerTask taskForOHLC[] = new TimerTask[intervalList.length];

		for (int i = 0; i < intervalList.length; i++) {

			final int idx2 = i;

			taskForOHLC[i] = new TimerTask() {
				@Override
				public void run() {
					int idx = idx2;

					for (int i = 0; i < coinList.length; i++) {

						// now를 startuTime[idx]로 바꿔도 됨!
						// long now = System.currentTimeMillis() / 1000;
						long now = startUtime[idx];

						String selectForHLV = String.format(
								" SELECT MAX(price), MIN(price), SUM(volume) FROM hitbtcOneMinute%s WHERE uTime BETWEEN %s and %s; ",
								coinList4DB[i], (now - intervalList[idx]), (now + 1));

						String selectForC = String.format(
								" SELECT price FROM hitbtcOneMinute%s WHERE uTime IN ( SELECT MAX(uTime) FROM hitbtcOneMinute%s WHERE uTime BETWEEN %s and %s);",
								coinList4DB[i], coinList4DB[i], (now - intervalList[idx]), (now + 1));

						String selectForO = String.format(
								"SELECT price FROM hitbtcOneMinute%s WHERE uTime < %s ORDER BY ABS(uTime - %s) LIMIT 1  ",
								coinList4DB[i], (now - intervalList[idx]), (now - intervalList[idx]));

						DB db = new DB();
						DB db2 = new DB();
						DB db3 = new DB();
						ResultSet rs = db.Query(selectForHLV, "select");
						ResultSet rs2 = db2.Query(selectForC, "select");
						ResultSet rs3 = db3.Query(selectForO, "select");

						double o = 0, h = 0, l = 0, c = 0, v = 0;

						try {
							// while (rs.next()) {
							//
							// h = rs.getDouble(1);
							// l = rs.getDouble(2);
							// v = rs.getDouble(3);
							// }
							// rs2.next();
							// c = rs2.getDouble(1);
							// rs3.next();
							// o = rs3.getDouble(1);

							if (rs.next() && rs2.next() && rs3.next()) {
								h = rs.getDouble(1);
								l = rs.getDouble(2);
								v = rs.getDouble(3);
								c = rs2.getDouble(1);
								o = rs3.getDouble(1);
							} else {
								System.out.println(
										"hitbtc" + LocalDateTime.now() + " : " + coinList[i] + "체결내역 0건 - 이전 최종 값 적용 ");

								String optimalSelectForC = String.format(
										"SELECT c FROM hitbtcOHLC_%s_%s WHERE uTime IN ( SELECT MAX(uTime) FROM hitbtcOHLC_%s_%s ) ",
										intervalList[idx], coinList4DB[i], intervalList[idx], coinList4DB[i]);
								DB newDB = new DB();
								ResultSet rsc = newDB.Query(optimalSelectForC, "select");
								try {
									if (rsc.next()) {
										double price = rsc.getDouble(1);
										o = price;
										h = price;
										l = price;
										c = price;
										v = 0;
									}
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								newDB.clean();
							}

						} catch (SQLException e) {
							// TODO Auto-generated catch block

							e.printStackTrace();
						}
						db.clean();
						db2.clean();
						db3.clean();

						long uTime = startUtime[idx];
						String insertSql = String.format(
								"INSERT INTO hitbtcOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s, \"EX\") ",
								intervalList[idx], coinList4DB[i], uTime, o, h, l, c, v);

						// DB dbInsert = new DB();
						dbInsert.Query(insertSql, "insert");
						// dbInsert.clean();

					}
					System.out.println("hitbtc " + intervalList[idx] + " done @  " + LocalDateTime.now());
					startUtime[idx] += intervalList[idx];
				}
			};
		}

		Date date = new Date();
		date.setTime((startUtimeSingle) * 1000);

		timer.scheduleAtFixedRate(taskForOneMinute, date, orderInterval * 1000);

		for (int i = 0; i < intervalList.length; i++) {

			Date date2 = new Date();
			date2.setTime((startUtimeSingle + intervalList[i]) * 1000);
			timer.scheduleAtFixedRate(taskForOHLC[i], date2, intervalList[i] * 1000);
			startUtime[i] += intervalList[i];
		}
	}

	public String getOrder(String coin) {

		String result = null;
		final String urlString = baseUrl + coin + "?sort=desc&limit=200";
		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				// result = getTicker(coin);
			} else {
				// Error 알람 전송
				e.printStackTrace();
				System.out.println("Maximum amount of attempts to connect to host exceeded.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}
		return result;
	}
}
