
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CryptoToDB extends Thread {

	final String baseUrl = "https://api.cryptowat.ch/markets/";
	private final int retryAttempts = 1;
	private int retryAttemptsLeft = 3;
	private final int retryDelaySeconds = 1;

	// "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "QTUM",
	// "BTG", "EOS", "ICX",
	private String[] bithumbCoinList = { "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "BTG", "EOS" };
	// 8 8 8 8 8 6 8 8 8 8 8
	// "btc", "bch", "eth", "etc", "xrp", "qtum", "iota", "ltc", "btg", "omg",
	// "eos", "data", "zil", "knc", "zrx"
	// private String[] coinoneCoinList = { "btc", "bch", "eth", "etc", "ltc", "btg"
	// };

	static String[] binanceCoinList = { "BCCUSDT", "BNBUSDT", "BTCUSDT", "ETHUSDT", "LTCUSDT", "NEOUSDT", "QTUMUSDT",
			"ADAUSDT", "EOSUSDT", "TUSDUSDT", "XLMUSDT", "XRPUSDT" };

	private String[] hitbtcCoinList = { "BTCUSDT", "BCHBTC", "ETHUSDT", "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC",
			"LTCUSDT", "DASHBTC", "ZRXETH", "ZECBTC" };

	private int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };

	private long after;
	private long before;
	private long startTime;

	public CryptoToDB(long after, long before, long startTime) {
		this.after = after;
		this.before = before;
		this.startTime = startTime;
	}

	@Override
	public void run() {
		System.out.println("no?");
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.out.println("CW start " + LocalDateTime.now());

				// DB db = new DB();
				// for (int i = 0; i < bithumbCoinList.length; i++) {
				//
				// for (int j = 0; j < intervalList.length; j++) {
				//
				// String ohlc_string = (getOHLC("bithumb", bithumbCoinList[i], "krw",
				// intervalList[j], after,
				// before));
				//
				// JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();
				// JsonArray ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject()
				// .get(intervalList[j] + "").getAsJsonArray());
				//
				// for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {
				//
				// long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
				// double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
				// double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
				// double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
				// double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
				// double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();
				//
				// String sql = String.format(
				// "INSERT INTO BithumbOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s, \"CW\") ",
				// intervalList[j], bithumbCoinList[i], uTime, o, h, l, c, v);
				// db.Query(sql, "insert");
				// db.clean(); // System.out.println(sql); }
				//
				// }
				// System.out.println("bth : " + bithumbCoinList[i] + intervalList[j] + "done");
				// }
				// }

				// DB db2 = new DB();
				// for (int i = 0; i < coinoneCoinList.length; i++) {
				//
				// for (int j = 0; j < intervalList.length; j++) {
				//
				// String ohlc_string = (getOHLC("coinone", coinoneCoinList[i], "krw",
				// intervalList[j], after, before));
				//
				// JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();
				// JsonArray ohlc_result_jsArr =
				// (ohlc_json.get("result").getAsJsonObject().get(intervalList[j] + "")
				// .getAsJsonArray());
				//
				// for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {
				//
				// long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
				// double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
				// double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
				// double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
				// double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
				// double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();
				//
				// String sql = String.format("INSERT INTO coinoneOHLC_%s_%s VALUES(%s, %s, %s,
				// %s, %s, %s,\"CW\") ",
				// intervalList[j], coinoneCoinList[i], uTime, o, h, l, c, v);
				//
				// db2.Query(sql, "insert");
				// db2.clean(); // System.out.println(sql); }
				//
				// }
				// System.out.println("coo : " + coinoneCoinList[i] + intervalList[j] + "done");
				// }
				// }

				// DB db3 = new DB();
				// for (int i = 0; i < binanceCoinList.length; i++) {
				//
				// for (int j = 0; j < intervalList.length; j++) {
				//
				// String ohlc_string = (getOHLC("binance", binanceCoinList[i], "",
				// intervalList[j], after,
				// before));
				//
				// JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();
				// JsonArray ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject()
				// .get(intervalList[j] + "").getAsJsonArray());
				//
				// for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {
				//
				// long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
				// double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
				// double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
				// double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
				// double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
				// double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();
				//
				// String sql = String.format(
				// "INSERT INTO binanceOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s,\"CW\") ",
				// intervalList[j], binanceCoinList[i], uTime, o, h, l, c, v);
				//
				// db3.Query(sql, "insert");
				// db3.clean();
				// // System.out.println(sql);
				// }
				// System.out.println("bnc : " + binanceCoinList[i] + intervalList[j] + "done");
				// }
				// }

				transferData2DB("hitbtc", hitbtcCoinList);
				transferData2DB("bithumb", bithumbCoinList);
				transferData2DB("binance", binanceCoinList);

				System.out.println("CW done " + LocalDateTime.now());
			}
		};

		System.out.println("no?2");
		Date startDate = new Date();
		startDate.setTime(startTime * 1000);
		System.out.println(startDate);
		Timer timer = new Timer();
		timer.schedule(task, startDate);
	}

	public void transferData2DB(String exchange, String[] exchangeCoinList) {

		DB db3 = new DB();
		for (int i = 0; i < exchangeCoinList.length; i++) {

			for (int j = 0; j < intervalList.length; j++) {

				String ohlc_string;
				if (exchange.equals("bithumb")) {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "krw", intervalList[j], after, before));
				} else {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "", intervalList[j], after, before));
				}
				JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();

				JsonArray ohlc_result_jsArr;
				try {
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(intervalList[j] + "")
							.getAsJsonArray());
				} catch (Exception e) {

					e.printStackTrace();
					System.out.println(intervalList[j] + " / " + exchangeCoinList[i] + " 에서 에러 !");
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(intervalList[j] + "")
							.getAsJsonArray());
				}

				for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {

					long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
					double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
					double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
					double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
					double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
					double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();

					String sql = String.format("INSERT INTO %sOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s,\"CW\") ",
							exchange, intervalList[j], exchangeCoinList[i], uTime, o, h, l, c, v);

					db3.Query(sql, "insert");
					db3.clean();
					// System.out.println(sql);
				}
				System.out.println(exchange + "  : " + exchangeCoinList[i] + intervalList[j] + "done");
			}
		}

		System.out.println(exchange + "done");
	}

	public String getOHLC(String exchange, String coin, String base, int interval, long after, long before) {

		String market = coin + base;
		String result = null;
		String urlString;

		if (after == 0) {
			urlString = baseUrl + exchange + "/" + market + "/" + "ohlc" + "?" + "periods=" + interval + "&before="
					+ (before + 100);
		} else {
			urlString = baseUrl + exchange + "/" + market + "/" + "ohlc" + "?" + "periods=" + interval + "&before="
					+ (before + 100) + "&after=" + (after - 100);
		}
		// System.out.println(urlString);
		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				result = getOHLC(exchange, coin, base, interval, after, before);

			} else {
				// Error 알람 전송 및 terminate;
				// tradingBot.terminateBot();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}

		// System.out.println("crypto result : \n" + result);
		return result;
	}

}
