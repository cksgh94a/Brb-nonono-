
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 실행 전에 uTime 설정 !

		// 09시 기준으로 돌려야함.
		// 크립토와치가 9시 기준으로 데이터를 쌓음
		// 이유는 세계시 기준 우리나라가 gmt + 9 이기 때문
		// 1시간데이터는 상관이 없지만, 하루데이터의 경우 데이터가 틀어짐
		 long uTime = Long.parseLong(args[0]);

		// OHLC 메이커
		// 거래소별 OHLC
		GetKorbitOHLC gKbOhlc = new GetKorbitOHLC(uTime);
		GetBithumbOHLC gBtOhlc = new GetBithumbOHLC(uTime);
		GetBinanceOHLC gBnOhlc = new GetBinanceOHLC(uTime);
		GetHitbtcOHLC gHbOhlc = new GetHitbtcOHLC(uTime);

		gKbOhlc.start();
		gBtOhlc.start();
		gHbOhlc.start();	
		gBnOhlc.start();
		/*
		 * 문서에서 서술한 대로
		 * 바이낸스는 이상하게 모든 코드가 동일함에도 불구하고
		 * 타이머가 잘 작동하지 않는 버그가 자주 발생하여
		 * 부득이하게 따로 프로그램을 생성.
		 */

	}
}
