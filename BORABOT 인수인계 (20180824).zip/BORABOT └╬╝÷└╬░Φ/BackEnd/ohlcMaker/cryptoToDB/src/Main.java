
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// from, to, startTime

		// 실행 전에 uTime 설정 !
		// 09시 기준으로 돌려야함.

		String exchange = args[0];
		long fromuTime = Long.parseLong(args[1]);
		long touTime = Long.parseLong(args[2]);
		long startTime = Long.parseLong(args[3]);

		// 안정적으로60초 뒤 시작 -> 시작(uTime)까지의 모든 데이터를 잘 받기 위해!
		CryptoToDB c2DB = new CryptoToDB(fromuTime, touTime, startTime, exchange);

		if(Integer.parseInt(args[4]) == 0) {
			c2DB.transfer();
			return;
		}
		else {
			for (int i = 4; i < args.length; i++) {
				c2DB.transferforEach(Integer.parseInt(args[i]));
			}
			return;
		}
	}
}
