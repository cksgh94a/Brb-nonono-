
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class CryptoToDB extends Thread {

	final String baseUrl = "https://api.cryptowat.ch/markets/";
	private final int retryAttempts = 1;
	private int retryAttemptsLeft = 3;
	private final int retryDelaySeconds = 1;

	private String[] bithumbCoinList = { "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "BTG", "EOS" };

	static String[] binanceCoinList = { "BCCUSDT", "BNBUSDT", "BTCUSDT", "ETHUSDT", "LTCUSDT", "NEOUSDT", "QTUMUSDT",
			"ADAUSDT", "EOSUSDT", "TUSDUSDT", "XLMUSDT", "XRPUSDT" };

	private String[] hitbtcCoinList = { "BTCUSDT", "BCHBTC", "ETHUSDT", "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC",
			"LTCUSDT", "DASHBTC", "ZRXETH", "ZECBTC" };

	private int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };

	private long after;
	private long before;
	private long startTime;
	private String ex;
	DBinsert db3 = new DBinsert();

	public CryptoToDB(long after, long before, long startTime, String exchange) {
		this.after = after;
		this.before = before;
		this.startTime = startTime;
		this.ex = exchange;
	}

	public void transfer() {

		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.out.println("CW start " + LocalDateTime.now());

				if (ex.equals("bithumb")) {

					transferData2DB("bithumb", bithumbCoinList);

				} else if (ex.equals("hitbtc")) {

					transferData2DB("hitbtc", hitbtcCoinList);

				} else if (ex.equals("binance")) {

					transferData2DB("binance", binanceCoinList);

				} else if (ex.equals("all")) {

					transferData2DB("hitbtc", hitbtcCoinList);
					transferData2DB("bithumb", bithumbCoinList);
					transferData2DB("binance", binanceCoinList);
				}
				System.out.println("CW done " + LocalDateTime.now());
			}
		};

		Date startDate = new Date();
		startDate.setTime(startTime * 1000);
		System.out.println("CW to DB start time : " + startDate);
		Timer timer = new Timer();
		timer.schedule(task, startDate);
	}

	public void transferData2DB(String exchange, String[] exchangeCoinList) {
		// 디비로 직접 전송하는 함수
		// 제이슨 파싱
		for (int i = 0; i < exchangeCoinList.length; i++) {

			for (int j = 0; j < intervalList.length; j++) {

				String ohlc_string;
				if (exchange.equals("bithumb")) {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "krw", intervalList[j], after, before));
				} else {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "", intervalList[j], after, before));
				}
				JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();

				JsonArray ohlc_result_jsArr;
				try {
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(intervalList[j] + "")
							.getAsJsonArray());
				} catch (Exception e) {

					e.printStackTrace();
					System.out.println(intervalList[j] + " / " + exchangeCoinList[i] + " 에서 에러 !");
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(intervalList[j] + "")
							.getAsJsonArray());
				}

				for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {

					long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
					double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
					double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
					double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
					double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
					double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();

					String sql = String.format("INSERT INTO %sOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s,\"CW\") ",
							exchange, intervalList[j], exchangeCoinList[i], uTime, o, h, l, c, v);

					db3.Query(sql, "insert");
					// System.out.println(sql);
				}
				System.out.println(exchange + "  : " + exchangeCoinList[i] + intervalList[j] + "done");
			}
		}

		System.out.println(exchange + "done");
	}

	public void transferforEach(int interval) {

		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.out.println("CW start " + LocalDateTime.now());

				if (ex.equals("bithumb")) {

					transferData2DBforEach("bithumb", bithumbCoinList, interval);

				} else if (ex.equals("hitbtc")) {

					transferData2DBforEach("hitbtc", hitbtcCoinList, interval);

				} else if (ex.equals("binance")) {

					transferData2DBforEach("binance", binanceCoinList, interval);

				} else if (ex.equals("all")) {

					transferData2DBforEach("hitbtc", hitbtcCoinList, interval);
					transferData2DBforEach("bithumb", bithumbCoinList, interval);
					transferData2DBforEach("binance", binanceCoinList, interval);
				}
				System.out.println("CW done " + LocalDateTime.now());
			}
		};

		Date startDate = new Date();
		startDate.setTime(startTime * 1000);
		System.out.println("CW to DB start time : " + startDate);
		Timer timer = new Timer();
		timer.schedule(task, startDate);
	}

	public void transferData2DBforEach(String exchange, String[] exchangeCoinList, int interval) {
		// 디비로 직접 전송하는 함수
		// 제이슨 파싱
		for (int i = 0; i < exchangeCoinList.length; i++) {

				String ohlc_string;
				if (exchange.equals("bithumb")) {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "krw", interval, after, before));
				} else {
					ohlc_string = (getOHLC(exchange, exchangeCoinList[i], "", interval, after, before));
				}
				JsonObject ohlc_json = new JsonParser().parse(ohlc_string).getAsJsonObject();

				JsonArray ohlc_result_jsArr;
				try {
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(interval+ "")
							.getAsJsonArray());
				} catch (Exception e) {

					e.printStackTrace();
					System.out.println(interval + " / " + exchangeCoinList[i] + " 에서 에러 !");
					ohlc_result_jsArr = (ohlc_json.get("result").getAsJsonObject().get(interval + "")
							.getAsJsonArray());
				}

				for (int k = 0; k < ohlc_result_jsArr.size() - 1; k++) {

					long uTime = ohlc_result_jsArr.get(k).getAsJsonArray().get(0).getAsLong();
					double o = ohlc_result_jsArr.get(k).getAsJsonArray().get(1).getAsDouble();
					double h = ohlc_result_jsArr.get(k).getAsJsonArray().get(2).getAsDouble();
					double l = ohlc_result_jsArr.get(k).getAsJsonArray().get(3).getAsDouble();
					double c = ohlc_result_jsArr.get(k).getAsJsonArray().get(4).getAsDouble();
					double v = ohlc_result_jsArr.get(k).getAsJsonArray().get(5).getAsDouble();

					String sql = String.format("INSERT INTO %sOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s,\"CW\") ",
							exchange, interval, exchangeCoinList[i], uTime, o, h, l, c, v);

					db3.Query(sql, "insert");
					// System.out.println(sql);
				}
				System.out.println(exchange + "  : " + exchangeCoinList[i] + interval + "done");
		}

		System.out.println(exchange + "done");
	}

	// 크립토와치에서 데이터를 콜하는 부분
	// json형식으로 오는 것을 문자열로 그대로 반환
	public String getOHLC(String exchange, String coin, String base, int interval, long after, long before) {

		String market = coin + base;
		String result = null;
		String urlString;

		if (after == 0) {
			urlString = baseUrl + exchange + "/" + market + "/" + "ohlc" + "?" + "periods=" + interval + "&before="
					+ (before + 100);
		} else {
			urlString = baseUrl + exchange + "/" + market + "/" + "ohlc" + "?" + "periods=" + interval + "&before="
					+ (before + 100) + "&after=" + (after - 100);
		}

		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				result = getOHLC(exchange, coin, base, interval, after, before);

			} else {
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}

		// System.out.println("crypto result : \n" + result);
		return result;
	}

}
