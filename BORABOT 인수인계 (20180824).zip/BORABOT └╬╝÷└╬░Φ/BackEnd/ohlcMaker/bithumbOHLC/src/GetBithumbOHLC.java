

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GetBithumbOHLC extends Thread {

	final static String baseUrl = "https://api.bithumb.com/public/transaction_history/";// currency_pair=zil_krw&time=minute";
	private final static int retryAttempts = 10;
	private static int retryAttemptsLeft = 10;
	private final static int retryDelaySeconds = 3;
	private String[] coinList = { "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "BTG", "EOS" };
	private long[] prevTimeForCoin = new long[coinList.length];
	private static int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };
	private volatile static long[] startUtime = new long[intervalList.length];
	private long startUtimeSingle;

	private static int orderInterval = 30;
	
	public GetBithumbOHLC(long ut) {
		this.startUtimeSingle = ut;
		Arrays.fill(startUtime, ut);
		Arrays.fill(prevTimeForCoin, ut - 1);
	}

	public static Date utToDate(long Utime) {

		Date date = new Date();
		date.setTime((long) Utime * 1000);

		return date;
	}

	public static long dateToUt(String dateStr) {

		long currentuTime = 0;
		try {
			Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateStr);
			currentuTime = date.getTime() / 1000;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return currentuTime;
	}

	@Override
	public void run() {

		Timer timer = new Timer();

		TimerTask taskForOneMinute = new TimerTask() {
			@Override
			public void run() {

				for (int i = 0; i < coinList.length; i++) {

					String result; // 에러
					try {
						result = getOrder(coinList[i]); // 에러
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("빗썸 오류");
						continue;
					}
					
					JsonArray jsArr = null;
					try {
						jsArr = new JsonParser().parse(result).getAsJsonObject().get("data").getAsJsonArray();
					}
					catch(Exception e) {
						e.printStackTrace();
						continue;
					}
					
					if (jsArr.size() == 0) {
//						System.out.println("bithumb" + coinList[i] + " no order");
					} else {
						JsonObject jsObj1 = jsArr.get(0).getAsJsonObject();
						String tempDate1 = jsObj1.get("transaction_date").getAsString();
						long tempPrev = dateToUt(tempDate1);
						// 이 부분을 cont_id 로 ... ?

						// 0 번쨰가 가장 최근?!
						for (int j = 0; j < jsArr.size(); j++) {

							JsonObject jsObj = jsArr.get(j).getAsJsonObject();

							String tempDate = jsObj.get("transaction_date").getAsString();

							long currentuTime = dateToUt(tempDate);

							// System.out.println(j +"th : " + currentuTime);

							if (currentuTime > prevTimeForCoin[i]) {
								// 삽입
								long id = jsObj.get("cont_no").getAsLong();
								double price = jsObj.get("price").getAsDouble();
								long uTime = dateToUt(jsObj.get("transaction_date").getAsString());
								double v = jsObj.get("units_traded").getAsDouble();

								String insertSQL = String.format(
										"INSERT INTO bithumbOneMinute%s VALUES (%s, %s, %s, %s) ", coinList[i], id,
										uTime, price, v);
								DB db = new DB();
								db.Query(insertSQL, "insert");
								db.clean();

							} else {
								break;
							}
						}

						// 마지막에 prev에다가 넣어줌
						prevTimeForCoin[i] = tempPrev;

					}
				}

//				System.out.println(orderInterval + "sec order bithumb insertion done");
			}
		};

		TimerTask taskForOHLC[] = new TimerTask[intervalList.length];

		for (int i = 0; i < intervalList.length; i++) {

			final int idx2 = i;
			
			taskForOHLC[i] = new TimerTask() {
				@Override
				public void run() {
					int idx = idx2;

					
					
					for (int i = 0; i < coinList.length; i++) {

						// now를 startuTime[idx]로 바꿔도 됨!
						long now = System.currentTimeMillis() / 1000;

						// System.out.println("now : " + now);
						String selectForHLV = String.format(
								" SELECT MAX(price), MIN(price), SUM(volume) FROM bithumbOneMinute%s WHERE uTime BETWEEN %s and %s; ",
								coinList[i], (now - intervalList[idx]), (now + 1));

						// System.out.println(coinList[i] + " : " + selectForHLV + " : " + utToDate(now
						// - intervalList[idx])+ " ~ " + utToDate(now + 1));

						String selectForC = String.format(
								" SELECT price FROM bithumbOneMinute%s WHERE uTime IN ( SELECT MAX(uTime) FROM bithumbOneMinute%s WHERE uTime BETWEEN %s and %s);",
								coinList[i], coinList[i], (now - intervalList[idx]), (now + 1));

						String selectForO = String.format(
								"SELECT price FROM bithumbOneMinute%s WHERE uTime < %s ORDER BY ABS(uTime - %s) LIMIT 1  ",
								coinList[i], (now - intervalList[idx]), (now - intervalList[idx]));

						DB db = new DB();
						DB db2 = new DB();
						DB db3 = new DB();
						ResultSet rs = db.Query(selectForHLV, "select");
						ResultSet rs2 = db2.Query(selectForC, "select");
						ResultSet rs3 = db3.Query(selectForO, "select");

						double o = 0, h = 0, l = 0, c = 0, v = 0;

						try {
							while (rs.next()) {

								h = rs.getDouble(1);
								l = rs.getDouble(2);
								v = rs.getDouble(3);
							}
							rs2.next();
							c = rs2.getDouble(1);
							rs3.next();
							o = rs3.getDouble(1);

						} catch (SQLException e) {
							// TODO Auto-generated catch block
							
								if(e.getMessage().contains("empty result set"))  {
									
									System.out.println("bithumb" + LocalDateTime.now()+ " : " + coinList[i] +"체결내역 0건 - 이전 최종 값 적용 ");
									
									String optimalSelectForC = String.format(
											"SELECT c FROM bithumbOHLC_%s_%s WHERE uTime IN ( SELECT MAX(uTime) FROM bithumbOHLC_%s_%s ) ", intervalList[idx], coinList[i], intervalList[idx], coinList[i] 
											);
									DB newDB = new DB();
									ResultSet rsc = newDB.Query(optimalSelectForC, "select");
									try {
										if(rsc.next()) {
											double price = rsc.getDouble(1);
											o = price; 
											h = price;
											l = price;
											c = price;
											v = 0;
										}
									} catch (SQLException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									newDB.clean();
								}
								else {
									e.printStackTrace();
								}
						}
						db.clean();
						db2.clean();
						db3.clean();

						long uTime = startUtime[idx];
						String insertSql = String.format(
								"INSERT INTO bithumbOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s, \"EX\") ", intervalList[idx],
								coinList[i], uTime, o, h, l, c, v);

						DB dbInsert = new DB();
						dbInsert.Query(insertSql, "insert");
						dbInsert.clean();

					}
					
					System.out.println("bithumb " + intervalList[idx] + " done @  " + LocalDateTime.now());
					startUtime[idx] += intervalList[idx];
				}
			};
		}

		Date date = new Date();
		date.setTime((startUtimeSingle) * 1000);

		timer.scheduleAtFixedRate(taskForOneMinute, date, orderInterval * 1000);

		for (int i = 0; i < intervalList.length; i++) {

			Date date2 = new Date();
			date2.setTime((startUtimeSingle + intervalList[i]) * 1000);
			timer.scheduleAtFixedRate(taskForOHLC[i], date2, intervalList[i] * 1000);
			startUtime[i] += intervalList[i];
		}

	}

	public String getOrder(String coin) {

		String result = null;
		final String urlString = baseUrl + coin + "?count=100";
		// System.out.println(urlString);
		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				// result = getTicker(coin);
			} else {
				// Error 알람 전송
				e.printStackTrace();
				System.out.println("Maximum amount of attempts to connect to host exceeded.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}
		return result;
	}
}
