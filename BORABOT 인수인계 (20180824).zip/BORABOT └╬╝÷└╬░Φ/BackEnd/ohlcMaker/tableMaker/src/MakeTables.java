
class MakeTables {

	private static String[] exchangeList = { "bithumb", "binance", "korbit", "hitbtc" };
	//
	// private static String[] coinoneCoinList = { "btc", "bch", "eth", "etc",
	// "xrp", "qtum", "iota", "ltc", "btg", "omg",
	// "eos", "data", "zil", "knc", "zrx" };

	private static String[] bithumbCoinList = { "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "BTG",
			"EOS", };

	private static String[] binanceCoinList = { "BCCUSDT", "BNBUSDT", "BTCUSDT", "ETHUSDT", "LTCUSDT", "NEOUSDT",
			"QTUMUSDT", "ADAUSDT", "EOSUSDT", "TUSDUSDT", "XLMUSDT", "XRPUSDT" };

	private static String[] korbitCoinList = { "BTC", "ETH", "XRP", "BCH", "ETC", "LTC" };

	private static String[] hitbtcCoinList = { "BTCUSDT", "BCHBTC", "ETHUSDT", "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC",
			"LTCUSDT", "DASHBTC", "ZRXETH", "ZECBTC" };

	private static int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };

	public static void makeTable() {

		makeOneMinuteTable("bithumb", bithumbCoinList);
		makeOneMinuteTable("binance", binanceCoinList);
		makeOneMinuteTable("korbit", korbitCoinList);
		makeOneMinuteTable("hitbtc", hitbtcCoinList);

		makeOHLCtable("bithumb", bithumbCoinList);
		makeOHLCtable("binance", binanceCoinList);
		makeOHLCtable("korbit", korbitCoinList);
		makeOHLCtable("hitbtc", hitbtcCoinList);

		System.out.println("table done");

		// // 바이낸스 1분 데이터 테이블
		// for (int i = 0; i < binanceCoinList.length; i++) {
		//
		// String sql = String.format(
		// "Create table binanceOneMinute%s ( t_id INT(12) primary key, uTime INT(11) ,
		// price double, volume double ) ",
		// binanceCoinList[i]);
		// DB dbT = new DB();
		// dbT.Query(sql, "insert");
		// dbT.clean();
		// }
		//
		// // 빗썸 1분 데이터
		// for (int i = 0; i < bithumbCoinList.length; i++) {
		//
		// String sql = String.format(
		// "Create table bithumbOneminute%s ( t_id INT(12) primary key, uTime INT(11) ,
		// price double, volume double ) ",
		// bithumbCoinList[i]);
		// DB dbT = new DB();
		// dbT.Query(sql, "insert");
		// dbT.clean();
		// }
		//
		// // 코빗 1분 데이터
		// for (int i = 0; i < korbitCoinList.length; i++) {
		//
		// String sql = String.format(
		// "Create table korbitOneminute%s ( t_id INT(12) primary key, uTime INT(11) ,
		// price double, volume double ) ",
		// korbitCoinList[i]);
		// DB dbT = new DB();
		// dbT.Query(sql, "insert");
		// dbT.clean();
		// }

		// for (int i = 0; i < intervalList.length; i++) {
		//
		// for (int j = 0; j < korbitCoinList.length; j++) {
		//
		// String sql = String.format(
		// "CREATE TABLE KorbitOHLC_%s_%s ( uTime INT(11) primary key, o double, h
		// double, l double, c double, v double null, src varchar(30) ) ",
		// intervalList[i], korbitCoinList[j]);
		// DB db2 = new DB();
		// db2.Query(sql, "insert");
		// db2.clean();
		// }
		// }
		//
		//// for (int i = 0; i < intervalList.length; i++) {
		////
		//// for (int j = 0; j < coinoneCoinList.length; j++) {
		////
		//// String sql = String.format(
		//// "CREATE TABLE CoinoneOHLC_%s_%s ( uTime INT(11) primary key, o double, h
		// double, l double, c double, v double null, src varchar(30) ) ",
		//// intervalList[i], coinoneCoinList[j]);
		//// DB db2 = new DB();
		//// db2.Query(sql, "insert");
		//// db2.clean();
		//// }
		//// }
		//
		// for (int i = 0; i < intervalList.length; i++) {
		//
		// for (int j = 0; j < bithumbCoinList.length; j++) {
		//
		// String sql = String.format(
		// "CREATE TABLE BithumbOHLC_%s_%s ( uTime INT(11) primary key, o double, h
		// double, l double, c double, v double null, src varchar(30) ) ",
		// intervalList[i], bithumbCoinList[j]);
		// DB db = new DB();
		// db.Query(sql, "insert");
		// db.clean();
		// }
		// }
		//
		// for (int i = 0; i < intervalList.length; i++) {
		//
		// for (int j = 0; j < binanceCoinList.length; j++) {
		//
		// String sql = String.format(
		// "CREATE TABLE BinanceOHLC_%s_%s ( uTime INT(11) primary key, o double, h
		// double, l double, c double, v double null, src varchar(30) ) ",
		// intervalList[i], binanceCoinList[j]);
		// DB db = new DB();
		// db.Query(sql, "insert");
		// db.clean();
		// }
		// }
		// System.out.println("table done");
	}

	public static void makeOneMinuteTable(String exchange, String[] exchangeCoinList) {

		// 코빗 1분 데이터
		for (int i = 0; i < exchangeCoinList.length; i++) {

			String sql = String.format(
					"Create table %sOneMinute%s ( t_id INT(12) primary key, uTime INT(11) , price double, volume double ) ",
					exchange, exchangeCoinList[i]);
			DB dbT = new DB();
			dbT.Query(sql, "insert");
			dbT.clean();
		}
	}

	public static void makeOHLCtable(String exchange, String[] exchangeCoinList) {

		for (int i = 0; i < intervalList.length; i++) {

			for (int j = 0; j < exchangeCoinList.length; j++) {

				String sql = String.format(
						"CREATE TABLE %sOHLC_%s_%s  ( uTime INT(11) primary key, o double, h double, l double, c double, v double null, src varchar(30) ) ",
						exchange, intervalList[i], exchangeCoinList[j]);
				DB db = new DB();
				db.Query(sql, "insert");
				db.clean();
			}
		}
	}

}
