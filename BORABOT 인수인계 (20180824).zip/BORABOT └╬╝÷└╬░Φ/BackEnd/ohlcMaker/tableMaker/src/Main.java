

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 MakeTables.makeTable();
		 System.out.println("table build complete");

	}
}
