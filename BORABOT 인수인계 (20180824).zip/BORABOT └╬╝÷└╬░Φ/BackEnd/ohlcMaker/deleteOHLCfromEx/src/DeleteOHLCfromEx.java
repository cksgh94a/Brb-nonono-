
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class DeleteOHLCfromEx {

	final String baseUrl = "https://api.cryptowat.ch/markets/";

	private String[] bithumbCoinList = { "BTC", "ETH", "DASH", "LTC", "ETC", "XRP", "BCH", "XMR", "ZEC", "BTG", "EOS" };

	static String[] binanceCoinList = { "BCCUSDT", "BNBUSDT", "BTCUSDT", "ETHUSDT", "LTCUSDT", "NEOUSDT", "QTUMUSDT",
			"ADAUSDT", "EOSUSDT", "TUSDUSDT", "XLMUSDT", "XRPUSDT" };

	private String[] hitbtcCoinList = { "BTCUSDT", "BCHBTC", "ETHUSDT", "XRPBTC", "ETHBTC", "BCHUSDT", "XMRBTC",
			"LTCUSDT", "DASHBTC", "ZRXETH", "ZECBTC" };

	private String ex;
	private int interval;

	public DeleteOHLCfromEx(String ex) {

		this.ex = ex;
	}

	public void delete(int interval) {

		System.out.println("EX erase start ");

		if (ex.equals("bithumb")) {
			deleteExData("bithumb", bithumbCoinList, interval);
		} else if (ex.equals("binance")) {
			deleteExData("binance", binanceCoinList, interval);
		} else if (ex.equals("hitbtc")) {
			deleteExData("hitbtc", hitbtcCoinList, interval);
		} else if (ex.equals("all")) {
			deleteExData("hitbtc", hitbtcCoinList, interval);
			deleteExData("bithumb", bithumbCoinList, interval);
			deleteExData("binance", binanceCoinList, interval);
		}

		System.out.println("EX delete done " + LocalDateTime.now());
	}

	public void deleteExData(String exchange, String[] exchangeCoinList, int interval) {

		DB db3 = new DB();
		for (int i = 0; i < exchangeCoinList.length; i++) {

			String delsql = String.format("delete from %sOHLC_%s_%s where src = 'Ex' ", exchange, interval,
					exchangeCoinList[i]);

			db3.Query(delsql, "insert");
			db3.clean();
			// System.out.println(sql);

			System.out.println(exchange + "  : " + exchangeCoinList[i] + interval + "ex erase done");
		}
		System.out.println(exchange + " deleting done");
	}
}
