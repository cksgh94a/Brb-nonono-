public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String exchange = args[0];

		DeleteOHLCfromEx del = new DeleteOHLCfromEx(exchange);
		
		// 인터벌 데이터를 적용
		for (int i = 0; i < args.length - 1; i++) {
			del.delete(Integer.parseInt(args[i + 1]));
		}
	}
}
