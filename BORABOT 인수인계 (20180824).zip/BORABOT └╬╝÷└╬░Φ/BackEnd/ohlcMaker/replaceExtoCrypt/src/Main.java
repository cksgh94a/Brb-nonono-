public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String exchange = args[0];
		long after = Long.parseLong(args[1]);
		long before = Long.parseLong(args[2]);

		ReplaceByCrypt rep = new ReplaceByCrypt(exchange, after, before);
		// 인터벌 데이터를 적용
		for (int i = 0; i < args.length - 1; i++) {
			rep.replace(Integer.parseInt(args[i + 1]));
		}

	}
}
