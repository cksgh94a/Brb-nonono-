
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		// 실행 전에 uTime 설정 !
		// 09시 기준으로 돌려야함.

		long uTime = Long.parseLong(args[0]);

		if (uTime < System.currentTimeMillis() / 1000) {
			uTime = System.currentTimeMillis() / 1000 + 120;
		}

		// OHLC 메이커
		GetBinanceOHLC gBnOhlc = new GetBinanceOHLC(uTime);

		gBnOhlc.start();
		System.out.println("binance ohlc making start");
	}
}
