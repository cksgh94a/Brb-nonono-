
import java.sql.*;
import java.util.Date;
import java.text.SimpleDateFormat;

public class DBinsert {

	String url = "jdbc:mysql://localhost:3306/borabot_ohlc?autoReconnect=true&useSSL=false&characterEncoding=UTF-8&serverTimezone=UTC";
	private Connection con = null;

	public DBinsert() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage() + "드라이버 로드 실패");
		}
		try {
			con = DriverManager.getConnection(url, "root", "1111");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// DB Query 함수
	private Statement stmt = null;
	private ResultSet rs = null; // ResultSet 객체 선언

	public ResultSet Query(String Sql, String INSSEL) {

		try {

			stmt = con.createStatement();

			// INSERT문
			stmt.executeUpdate(Sql);

		} catch (SQLException se) {
			if (se.getMessage().contains("Duplicate entry")) {
				System.out.println("키 중복");
				se.printStackTrace();
			} else
				se.printStackTrace();

		}
		return rs;
	}

	public void clean() {

		try {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}
}