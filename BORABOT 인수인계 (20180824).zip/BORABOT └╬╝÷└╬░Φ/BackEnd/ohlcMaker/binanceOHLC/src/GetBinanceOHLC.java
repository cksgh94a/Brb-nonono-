
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GetBinanceOHLC extends Thread {

	final static String baseUrl = "https://api.binance.com/api/v1/trades?symbol=";// currency_pair=zil_krw&time=minute";
	private final static int retryAttempts = 10;
	private static int retryAttemptsLeft = 10;
	private final static int retryDelaySeconds = 3;
	static String[] coinList = { "BCCUSDT", "BNBUSDT", "BTCUSDT", "ETHUSDT", "LTCUSDT", "NEOUSDT", "QTUMUSDT",
			"ADAUSDT", "EOSUSDT", "TUSDUSDT", "XLMUSDT", "XRPUSDT" };
	private long[] prevTimeForCoin = new long[coinList.length];
	private static int[] intervalList = { 300, 1800, 3600, 21600, 43200, 86400 };
	private volatile static long[] startUtime = new long[intervalList.length];
	private long startUtimeSingle;
	private static int orderInterval = 60;
	DBinsert db = new DBinsert();

	public GetBinanceOHLC(long ut) {
		this.startUtimeSingle = ut;
		Arrays.fill(startUtime, ut);
		Arrays.fill(prevTimeForCoin, ut - 1);

	}

	@Override
	public void run() {

		// for (int i = 0; i < coinList.length; i++) {
		//
		// String sql = String.format(
		// "Create table binanceOneMinute%s ( t_id INT(12) primary key, uTime INT(11) ,
		// price double, volume double ) ",
		// coinList[i]);
		// DB dbT = new DB();
		// dbT.Query(sql, "insert");
		// dbT.clean();
		//
		// }
		//
		// System.out.println("table done");

		Timer timer = new Timer();

		TimerTask taskForOneMinute = new TimerTask() {
			@Override
			public void run() {

				for (int i = 0; i < coinList.length; i++) {

					String result; // 에러
					try {
						result = getOrder(coinList[i]); // 에러
					} catch (Exception e) {

						System.out.println("바이낸스 오류");
						e.printStackTrace();
						continue;
					}

					JsonArray jsArr = new JsonParser().parse(result).getAsJsonArray();
					if (jsArr.size() == 0) {
						System.out.println("binance" + coinList[i] + " no order");
					} else {
						JsonObject jsObj1 = jsArr.get(jsArr.size() - 1).getAsJsonObject();
						long tempPrev = jsObj1.get("time").getAsLong() / 1000;

						// 0 번쨰가 가장 최근?!
						// 앗.. 마지막이 젤 최근이다 얘는..
						for (int j = jsArr.size() - 1; j >= 0; j--) {

							JsonObject jsObj = jsArr.get(j).getAsJsonObject();
							long currentuTime = jsObj.get("time").getAsLong() / 1000;

							// System.out.println(j +"th : " + currentuTime);

							if (currentuTime > prevTimeForCoin[i]) {
								// 삽입
								long t_id = jsObj.get("id").getAsLong();
								double price = jsObj.get("price").getAsDouble();
								long uTime = (jsObj.get("time").getAsLong()) / 1000;
								double v = jsObj.get("qty").getAsDouble();

								String insertSQL = String.format(
										"INSERT INTO binanceOneMinute%s VALUES (%s, %s, %s, %s) ", coinList[i], t_id,
										uTime, price, v);

								db.Query(insertSQL, "insert");

							} else {
								break;
							}
						}
						// 마지막에 prev에다가 넣어줌
						prevTimeForCoin[i] = tempPrev;
					}
				}
			}
		};

		TimerTask taskForOHLC[] = new TimerTask[intervalList.length];

		for (int i = 0; i < intervalList.length; i++) {

			final int idx = i;
			taskForOHLC[i] = new TimerTask() {
				@Override
				public void run() {

					System.out.println("binance task start log " + LocalDateTime.now());

					for (int i = 0; i < coinList.length; i++) {

						long now = System.currentTimeMillis() / 1000;
						// System.out.println("now : " + now);
						String selectForHLV = String.format(
								" SELECT MAX(price), MIN(price), SUM(volume) FROM binanceOneMinute%s WHERE uTime BETWEEN %s and %s; ",
								coinList[i], now - intervalList[idx], now + 1);

						String selectForC = String.format(
								" SELECT price FROM binanceOneMinute%s WHERE uTime IN ( SELECT MAX(uTime) FROM binanceOneMinute%s WHERE uTime BETWEEN %s and %s);",
								coinList[i], coinList[i], now - intervalList[idx], now + 1);

						String selectForO = String.format(
								"SELECT price FROM binanceOneMinute%s WHERE uTime < %s ORDER BY ABS(uTime - %s) LIMIT 1  ",
								coinList[i], now - intervalList[idx], now - intervalList[idx]);

						DB db = new DB();
						DB db2 = new DB();
						DB db3 = new DB();
						ResultSet rs = db.Query(selectForHLV, "select");
						ResultSet rs2 = db2.Query(selectForC, "select");
						ResultSet rs3 = db3.Query(selectForO, "select");

						double o = 0, h = 0, l = 0, c = 0, v = 0;

						try {
							
							if (rs.next() && rs2.next() && rs3.next()) {
								h = rs.getDouble(1);
								l = rs.getDouble(2);
								v = rs.getDouble(3);
								c = rs2.getDouble(1);
								o = rs3.getDouble(1);
							} else {

								System.out.println("binance" + LocalDateTime.now() + " : " + coinList[i]
										+ "체결내역 0건 - 이전 최종 값 적용 ");

								String optimalSelectForC = String.format(
										"SELECT c FROM binanceOHLC_%s_%s WHERE uTime IN ( SELECT MAX(uTime) FROM binanceOHLC_%s_%s ) ",
										intervalList[idx], coinList[i], intervalList[idx], coinList[i]);

								DB newDB = new DB();
								ResultSet rsc = newDB.Query(optimalSelectForC, "select");
								try {
									if (rsc.next()) {
										double price = rsc.getDouble(1);
										o = price;
										h = price;
										l = price;
										c = price;
										v = 0;
									}
								} catch (SQLException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								newDB.clean();
							}

						} catch (SQLException e) {
							// TODO Auto-generated catch block

							e.printStackTrace();

						}

						db.clean();
						db2.clean();
						db3.clean();

						long uTime = startUtime[idx];
						String insertSql = String.format(
								"INSERT INTO binanceOHLC_%s_%s VALUES(%s, %s, %s, %s, %s, %s,\"Ex\") ",
								intervalList[idx], coinList[i], uTime, o, h, l, c, v);

						DB dbInsert = new DB();
						dbInsert.Query(insertSql, "insert");
						dbInsert.clean();

					}
					startUtime[idx] += intervalList[idx];
					System.out.println("binance " + intervalList[idx] + " done @  " + LocalDateTime.now());
				}
			};
		}

		Date date = new Date();
		date.setTime((startUtimeSingle) * 1000);

		timer.scheduleAtFixedRate(taskForOneMinute, date, orderInterval * 1000);

		for (int i = 0; i < intervalList.length; i++) {

			Date date2 = new Date();
			date2.setTime((startUtimeSingle + intervalList[i]) * 1000);
			timer.scheduleAtFixedRate(taskForOHLC[i], date2, intervalList[i] * 1000);
			startUtime[i] += intervalList[i];
		}

	}

	public String getOrder(String coin) {

		String result = null;
		final String urlString = baseUrl + coin;
		// System.out.println(urlString);
		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				// result = getTicker(coin);
			} else {
				// Error 알람 전송
				e.printStackTrace();
				System.out.println("Maximum amount of attempts to connect to host exceeded.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}
		return result;
	}

	public String getLimit() {

		String result = null;
		final String urlString = "https://api.binance.com/api/v1/exchangeInfo";
		// System.out.println(urlString);
		try {
			URL url = new URL(urlString);
			HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));

			StringBuffer resultBuffer = new StringBuffer();
			String line = "";

			while ((line = reader.readLine()) != null)
				resultBuffer.append(line);
			result = resultBuffer.toString();

		} catch (UnknownHostException | SocketException e) {

			if (retryAttemptsLeft-- > 0) {
				System.err.printf("Could not connect to host - retrying in %d seconds... [%d/%d]%n", retryDelaySeconds,
						retryAttempts - retryAttemptsLeft, retryAttempts);
				try {
					Thread.sleep(retryDelaySeconds * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				// result = getTicker(coin);
			} else {
				// Error 알람 전송
				e.printStackTrace();
				System.out.println("Maximum amount of attempts to connect to host exceeded.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			retryAttemptsLeft = retryAttempts;
		}
		return result;
	}
}
