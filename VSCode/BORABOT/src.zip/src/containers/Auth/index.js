export { default as Login } from './Login';
export { default as Register } from './Register';
export { default as Main } from './Term';
// export { default as Profile } from './Profile';
