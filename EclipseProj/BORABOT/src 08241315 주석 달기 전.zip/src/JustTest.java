//import java.io.UnsupportedEncodingException;
//import java.security.NoSuchAlgorithmException;
//
//import DB.Hash;
//
//public class JustTest {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		
//		try {
//			System.out.println(new Hash().hashing("test"));
//		} catch (NoSuchAlgorithmException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//
//}
