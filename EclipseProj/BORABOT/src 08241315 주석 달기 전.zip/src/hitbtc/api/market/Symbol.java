/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

package hitbtc.api.market;

public class Symbol {
    public String symbol, currency, commodity;
    public double step, lot, takeLiquidityRate, provideLiquidityRate;
}