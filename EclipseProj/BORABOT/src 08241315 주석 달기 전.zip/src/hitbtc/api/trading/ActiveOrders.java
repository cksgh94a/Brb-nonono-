/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

/*
 * Mykhailo Pietielin 2017.
 * https://github.com/RoanDev
 * roanworkbox@gmail.com
 * GPL c:
 */

package hitbtc.api.trading;

import java.util.ArrayList;

public class ActiveOrders {
    public ArrayList<TradeOrder> orders = new ArrayList<>();
}
