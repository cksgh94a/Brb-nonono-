package backtest;

public interface calcIndicator_bt {

	public int getDeterminConstant() throws Exception;
	
}
