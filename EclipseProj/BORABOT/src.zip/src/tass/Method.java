package tass;

public class Method {

	
	
	
}
